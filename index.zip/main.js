function redirecionarParaIndex() {
    window.location.href = "index.html#area";
}

// var nav = document.querySelector('nav');

// window.addEventListener('scroll', function () {
//     if (window.scrollY > 200) {
//         nav.classList.add('navbarvermelho', 'shadow');
//     } else {
//         nav.classList.remove('navbarvermelho', 'shadow');
//     }
// });



